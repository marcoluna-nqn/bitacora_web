import 'dart:typed_data';

Future<void> saveXlsxBytes(Uint8List bytes, String fileName) async {
  throw UnsupportedError(
      'Exportación XLSX soportada solo en Web en este proyecto.');
}
